import { createSlice } from "@reduxjs/toolkit";

const initialState = [
	{
		id: 1,
		name: "Japan",
		price: 12.99,
		category: "Education",
	},
	{
		id: 2,
		name: "Japan2",
		price: 13.99,
		category: "Education",
	},
];

export const crudSlice = createSlice({
	name: "crud",
	initialState,
	reducers: {
		addBook: (state, action) => {
			state.push(action.payload);
		},
		updateBook: (state, action) => {
			const { id, name, price, category } = action.payload;
			const existingBook = state.find((book) => {
				return book.id === id;
			});
			if (existingBook) {
				existingBook.name = name;
				existingBook.price = price;
				existingBook.category = category;
			}
		},
		deleteBook: (state, action) => {
			const id = action.payload;
			console.log(id);
			state.filter((book) => book.id !== id);
		},
	},
});

export const { addBook, deleteBook, updateBook } = crudSlice.actions;

export default crudSlice.reducer;
