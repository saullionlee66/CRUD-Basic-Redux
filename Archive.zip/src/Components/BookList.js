import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import EditBook from "./EditBook";
import AddBook from "./AddBook";
import Book from "./Book";
function BookList() {
	const [openAdd, setOpenAdd] = useState(false);

	const books = useSelector((state) => state.crud);

	return (
		<div>
			{books &&
				books.map((book) => {
					return (
						<Book
							key={book.id}
							id={book.id}
							name={book.name}
							price={book.price}
							category={book.category}
						/>
					);
				})}
			<button
				onClick={() => {
					setOpenAdd(true);
				}}>
				Add
			</button>
			{openAdd && <AddBook setOpenAdd={setOpenAdd} />}
		</div>
	);
}

export default BookList;
