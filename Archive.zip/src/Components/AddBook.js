import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addBook } from "../Redux/crudSlice";
function AddBook({ setOpenAdd }) {
	const dispatch = useDispatch();
	const [book, setBook] = useState({});

	const booksQTY = useSelector((state) => state.crud.length);

	const handleClick = (e) => {
		e.preventDefault();
		dispatch(addBook(book));
	};
	const handleChange = (e) => {
		const { name, value } = e.target;
		setBook({ ...book, id: booksQTY + 1, [name]: value });
	};
	return (
		<div>
			<form>
				<div>
					<label>Book Name</label>
					<input
						type='text'
						name='name'
						id='name'
						placeholder='Enter name here...'
						onChange={handleChange}
						required
					/>
				</div>
				<div>
					<label>Book Price</label>
					<input
						type='number'
						name='price'
						id='price'
						placeholder='Enter price here...'
						onChange={handleChange}
						required
					/>
				</div>
				<div>
					<label>Book Category</label>
					<input
						type='text'
						name='category'
						id='category'
						placeholder='Enter category here...'
						onChange={handleChange}
						required
					/>
				</div>
				<button
					onClick={() => {
						setOpenAdd(false);
					}}>
					Cancel
				</button>
				<button type='submit' onClick={handleClick}>
					Add Book
				</button>
			</form>
		</div>
	);
}

export default AddBook;
