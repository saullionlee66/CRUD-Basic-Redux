import React, { useState } from "react";
import { deleteBook } from "../Redux/crudSlice";
import { useDispatch } from "react-redux";
import EditBook from "./EditBook";
import "../App.css";
function Book({ id, name, price, category }) {
	const dispatch = useDispatch();
	const [openUpdate, setOpenUpdate] = useState(false);
	const handleDelete = (e) => {
		dispatch(deleteBook(e.target.id));
	};
	return (
		<div className='book-container'>
			<div onClick={() => setOpenUpdate(true)}>
				<p>ID: {id}</p>
				<p>Name: {name}</p>
				<p>Price: {price}</p>
				<p>Category: {category}</p>
			</div>
			<div>
				<button id={id} onClick={handleDelete}>
					Delete
				</button>
			</div>
			<div>
				{openUpdate && <EditBook id={id} setOpenUpdate={setOpenUpdate} />}
			</div>
		</div>
	);
}

export default Book;
