import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { updateBook } from "../Redux/crudSlice";
function EditBook({ id, setOpenUpdate }) {
	const [newBook, setNewBook] = useState({});

	const dispatch = useDispatch();
	const handleChange = (e) => {
		const { name, value } = e.target;
		setNewBook({ ...newBook, id, [name]: value });
	};

	const handleClick = (e) => {
		e.preventDefault();
		dispatch(updateBook(newBook));
	};
	return (
		<div>
			<form>
				<div>
					<label>Book Name</label>
					<input
						type='text'
						name='name'
						id='name'
						placeholder='Leave Empty with no change'
						onChange={handleChange}
					/>
				</div>
				<div>
					<label>Book Price</label>
					<input
						type='number'
						name='price'
						id='price'
						placeholder='Leave Empty with no change'
						onChange={handleChange}
					/>
				</div>
				<div>
					<label>Book Category</label>
					<input
						type='text'
						name='category'
						id='category'
						placeholder='Leave Empty with no change'
						onChange={handleChange}
					/>
				</div>
				<button
					onClick={(e) => {
						e.preventDefault();
						setOpenUpdate(false);
					}}>
					Cancel
				</button>
				<button type='submit' onClick={handleClick}>
					Update Book
				</button>
			</form>
		</div>
	);
}

export default EditBook;
